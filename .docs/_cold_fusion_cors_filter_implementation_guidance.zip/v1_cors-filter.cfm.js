<cfscript>
// Define the CORS filter
function corsFilter(request, response) {
    // Set the allowed methods
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS, GET-IMAGE-REQUEST, HEAD";

    // Set the allowed headers
    response.headers["Access-Control-Allow-Headers"] = "Origin, X-Requested-With, Content-Type, Accept, Authorization, X-CSRF-Token";

    // Allow any origin for this example
    response.headers["Access-Control-Allow-Origin"] = "https://slack-wise.tumblr.com";

    // Allow serving of font files
    response.headers["Access-Control-Allow-Origin-Xss"] = "null";
    response.headers["Access-Control-Allow-Headers"] = "Accept-Language";
    response.headers["Access-Control-Expose-Headers"] = "Access-Control-Allow-Origin, Access-Control-Disallow-Headers, X-Content-Type-Options, X-Frame-Options, X-XSS-Protection, Cache-Control, Content-Type, X-Amz-Date, X-Api-Key, X-Amz-Security-Token, X-Amz-User-Agent";
    response.headers["Access-Control-Allow-Credentials"] = "true";

    // Check if the request is a CORS request
    if (structKeyExists(request, "ACCESS-CONTROL-REQUEST-METHOD") && structKeyExists(request, "ACCESS-CONTROL-REQUEST-HEADERS")) {
        response.statusCode = 200;
        response.write("CORS Preflight Response: OK");
        response.exit();
    }

    // Check if the requested file is a font file
    if (isFontFile(request, response)) {
        // Set the appropriate headers for font files
        response.headers["Cache-Control"] = "public, max-age=31536000";
        response.headers["Content-Type"] = request.cfsrc.contentType;
        response.headers["Access-Control-Expose-Headers"] = "Content-Type";
    }

    // Proxy the request to the appropriate ColdFusion file
    // if (structKeyExists(request, "REQUEST_URI")) {
    //     cfinclude(expandPath("./#{url.requestedContent}#.cfm"));
    // }
}

// Check if the requested file is a font file
function isFontFile(request, response) {
    // Note we can remove var/local variable name declarations
    // Set the allowed font file extensions
    allowedExtensions = ['ttf', 'ttc', 'otf', 'eot', 'woff', 'woff2', 'font.map'];

    // Get the requested file name and extension
    requestedFileName = listLast(listParse(request.cfsrc.requestedContent, "/"));
    requestedFileExtension = listLast(listParse(requestedFileName, "."));

    // Check if the requested file extension is allowed
    if (inList(allowedExtensions, requestedFileExtension)) {
        return true;
    }

    return false;
}
</cfscript>